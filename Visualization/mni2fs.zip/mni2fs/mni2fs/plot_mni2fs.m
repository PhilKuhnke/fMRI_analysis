
clear all
close all

%% Setup

%%% Add toolbox path
toolboxpath = 'E:\Dropbox\PhD\Lehre\Anwendung2_fMRT_Analyse\2023\Sitzungen\10_Visualisierung_und_Interpretation\Matlab\mni2fs\mni2fs\mni2fs_Feb19';
addpath(genpath(toolboxpath))

%% Plot ROI and Overlay
close all
%figure
figure('Color','w','position',[20 20 1800 800])

% Load and Render the FreeSurfer surface
S = [];
S.hem = 'rh'; %%% chose hemisphere (left = 'lh', right = 'rh')
S.inflationstep = 6; %%% choose inflation (1 = none, 6 = full)
S.plotsurf = 'inflated';
S.lookupsurf = 'smoothwm';
S.decimation = false; 
S = mni2fs_brain(S);

%%% Camera settings
view([-80 0]) % left lateral: [-100 0]; left medial / right lateral: [100 0]; 
               % right medial: [-80 0]; left medial-ventral: [100 -60]; 
               % left lateral-ventral / right medial-ventral: [-95 -35]

mni2fs_lights('on')

%%% Define overlay path (to thresholded .nii image)
overlay1_path = 'D:\fMRI_Datasets\ds000117_done\derivatives\second_level\one_sample_ttests\FACES_VS_SCRAMBLED\Faces_vs_Scrambled_voxel001_cFWE05.nii'

% turn NaNs into 0s
nii = mni2fs_load_nii(overlay1_path);
nifti_img = nii.img;
nifti_img(isnan(nifti_img)) = 0;
nii.img = nifti_img

S.mnivol = nii;
S.climstype = 'pos';
S.interpmethod = 'spline';

% 'autumn', 'winter', dark red [0.8 0 0], yellow [0.9 0.9 0], orange [1 0.5 0], 
% blue [0 0 0.9], purple [0.8 0.35 1], green [0 0.9 0]
S.colormap = 'autumn'; %%% choose colormap
S.clims = [2 6]; %%% choose range of T-values
S = mni2fs_overlay(S);

%% Optional: add another overlay

%%% Define overlay path (to thresholded .nii image)
overlay2_path = 'D:\fMRI_Datasets\ds000117_done\derivatives\second_level\one_sample_ttests\FACES_VS_SCRAMBLED\Scrambled_vs_Faces_voxel001_cFWE05.nii'

% turn NaNs into 0s
nii = mni2fs_load_nii(overlay2_path);
nifti_img = nii.img;
nifti_img(isnan(nifti_img)) = 0;
nii.img = nifti_img

S.mnivol = nii;
S.climstype = 'pos';
S.interpmethod = 'spline';

% 'autumn', 'winter', dark red [0.8 0 0], yellow [0.9 0.9 0], orange [1 0.5 0], 
% blue [0 0 0.9], purple [0.8 0.35 1], green [0 0.9 0]
S.colormap = 'winter'; %%% choose colormap
S.clims = [2 6]; %%% choose range of T-values
S = mni2fs_overlay(S);

%% For high quality output 
% Try export_fig package included in this release
% When using export fig use the bitmap option 

export_fig('Action_leftLat.bmp','-bmp','-m3')
